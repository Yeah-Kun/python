

if __name__ == '__main__':
	print("主程序运行")
else:
	print("package 初始化")